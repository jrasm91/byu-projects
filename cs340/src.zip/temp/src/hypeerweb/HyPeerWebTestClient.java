package hypeerweb;

import gui.Main.GUI;
import hypeerweb.node.Node;

import java.net.InetAddress;

import distributed.GlobalObjectId;
import distributed.LocalObjectId;
import distributed.ObjectDB;
import distributed.PeerCommunicator;
import distributed.PortNumber;
import distributed.example.TestClassProxy;

public class HyPeerWebTestClient {

	public static void main(String[] args) {
		ObjectDB.setFileLocation("ObjectDB.db");
		try{
    		String myIPAddress = InetAddress.getLocalHost().getHostAddress();
			GlobalObjectId serverGlobalObjectId =
				new GlobalObjectId(myIPAddress,
						           PortNumber.DEFAULT_PORT_NUMBER,
								   null);
			
			PeerCommunicator.createPeerCommunicator(new PortNumber(49201));
			
			GlobalObjectId testClassGlobalObjectId =
				new GlobalObjectId(myIPAddress,
						           PortNumber.DEFAULT_PORT_NUMBER,
						           new LocalObjectId(Integer.MIN_VALUE)
				                  );
			HyPeerWebProxy proxy = new HyPeerWebProxy(testClassGlobalObjectId);
			
			System.out.println("Proxy's size: " + proxy.size());
			proxy.addToHyPeerWeb(new Node(0), null);
			Node node0 = proxy.getNode(0);
			System.out.println("Node0: " + node0.getWebId().getValue());
			System.out.println("Proxy's size: " + proxy.size());
			
			proxy.addToHyPeerWeb(new Node(0), null);
			System.out.println("Proxy's size: " + proxy.size());
//			Node node1 = proxy.getNode(1);
//			System.out.println("Node1: " + node1.getWebId().getValue());
//			System.out.println("Proxy's size: " + proxy.size());

//			GUI.getSingleton(proxy);
			
			PeerCommunicator.stopConnection(serverGlobalObjectId);
			PeerCommunicator.stopThisConnection();
		} catch(Exception e){
		    System.err.println(e.getMessage());
		    e.printStackTrace();
		}
	}

}
