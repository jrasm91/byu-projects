package hypeerweb;

import distributed.ObjectDB;
import distributed.PeerCommunicator;
import distributed.PortNumber;
import distributed.example.TestClass;

public class HyPeerWebTestServer {

	public static void main(String[] args) {
		ObjectDB.setFileLocation("Database.db");
		ObjectDB.getSingleton().clear();
		HyPeerWeb hypeerweb = HyPeerWeb.getSingleton();
		ObjectDB.getSingleton().store(hypeerweb.getLocalObjectId(), hypeerweb);
		System.out.println(hypeerweb.getLocalObjectId().getId());
		ObjectDB.getSingleton().save("Database.db");
		
		ObjectDB.setFileLocation("Database.db");
		ObjectDB.getSingleton().restore(null);
        System.out.println("Server::main(String[]) ObjectDB = ");
        ObjectDB.getSingleton().dump();
        
		try{
			System.out.println("Starting peer comunicator (server)");
			System.out.println("PortNumber: " + PortNumber.DEFAULT_PORT_NUMBER);
			PeerCommunicator.createPeerCommunicator();
		}catch(Exception e){
			System.err.println(e.getMessage());
			System.err.println(e.getStackTrace());
		}
	}
}
