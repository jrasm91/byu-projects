package hypeerweb.node;

import java.util.HashMap;
import java.util.Map;

public class Contents {

	private Map<String, Object> contents;

	public Contents() {
		contents = new HashMap<String, Object>();
	}

	public Object get(String key) {
		return contents.get(key);
	}

	public boolean containsKey(String key) {
		return contents.containsKey(key);
	}

	public void set(String key, Object value) {
		contents.put(key, value);
	}
	
	public void clear() {
		contents.clear();
	}
}
