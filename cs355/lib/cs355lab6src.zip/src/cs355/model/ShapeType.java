package cs355.model;

public enum ShapeType {
	
	LINE, RECTANGLE, SQUARE, ELLIPSE, CIRCLE, TRIANGLE;

}
