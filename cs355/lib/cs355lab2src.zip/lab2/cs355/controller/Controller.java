package cs355.controller;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import cs355.gui.GUIFunctions;
import cs355.model.Line;
import cs355.model.Model;
import cs355.model.Shape;
import cs355.model.ShapeType;
import cs355.utility.Utility;

public class Controller implements cs355.gui.CS355Controller {

	private static Logger logger;

	static {
		logger = Logger.getLogger(Class.class.getName());
		logger.setLevel(Level.ALL);
		ConsoleHandler ch = new ConsoleHandler();
		ch.setLevel(Level.ALL);
		logger.addHandler(ch);
	}

	private static Controller singleton = new Controller();

	private StateType selectedState;
	
	private boolean selectedHandle;
	private boolean selectedDragging;
	private boolean selectedRotation;
	private boolean selectedTriangle;
	
	private Point draggingOffset;
	private Color selectedColor;
	private Shape selectedShape;

	private int zoom;
	private List<Point> trianglePoints;
	private Point downPoint;

	private Controller(){
		trianglePoints = new ArrayList<Point>();
		selectedColor = Color.BLUE;
		selectedState = StateType.NONE;
	}

	public static Controller singleton(){
		return singleton;
	}

	public Shape getSelectedShape() {
		return selectedShape;
	}

	public int getZoom() {
		return zoom;
	}

	/**
	 * Resets all states, variables
	 */
	private void reset(){
		selectedState = StateType.NONE;
		selectedHandle = false;
		selectedRotation = false;
		selectedDragging = false;
		selectedTriangle = false;
		trianglePoints.clear();
		downPoint = null;
		selectedShape = null;
		draggingOffset = new Point(0, 0);
		zoom = 100;
		GUIFunctions.refresh();
	}

	@Override
	public void colorButtonHit(Color c) {
		if(c == null) return;
		selectedColor = c;	
		if(selectedShape != null)
			selectedShape.setColor(selectedColor);
		GUIFunctions.changeSelectedColor(c);
		GUIFunctions.refresh();
	}
	
	@Override
	public void selectButtonHit() {
		reset();
		selectedState = StateType.SELECT_SHAPE;
//		selectedShape = Model.singleton().getLastShape();
		GUIFunctions.refresh();
	}


	@Override
	public void triangleButtonHit() { reset(); selectedState = StateType.DRAW_TRIANGLE; }

	@Override
	public void squareButtonHit() { reset(); selectedState = StateType.DRAW_SQUARE;	}

	@Override
	public void rectangleButtonHit() { reset(); selectedState = StateType.DRAW_RECTANGLE; }

	@Override
	public void circleButtonHit() { reset(); selectedState = StateType.DRAW_CIRCLE; }

	@Override
	public void ellipseButtonHit() { reset(); selectedState = StateType.DRAW_ELLIPSE; }

	@Override
	public void lineButtonHit() { reset(); selectedState = StateType.DRAW_LINE; }

	@Override
	public void zoomInButtonHit() { }

	@Override
	public void zoomOutButtonHit() { }

	@Override
	public void hScrollbarChanged(int value) { }

	@Override
	public void vScrollbarChanged(int value) { }
	
	public void mouseClicked(Point point) {
		switch(selectedState){
		case NONE:
			break;
		case DRAW_TRIANGLE:
			if(trianglePoints.contains(point)) return;
			trianglePoints.add(point);
			if(trianglePoints.size() == 3){
				ShapeUpdater.addShape(trianglePoints, selectedColor);
				trianglePoints.clear();
			}
			break;
		case SELECT_SHAPE:
			if(HandleHitTester.isHittingBoxHandles(point, selectedShape))
				return;
			selectedShape = ShapeHitTester.findSelectedShape(point);
			if(selectedShape != null) 
				colorButtonHit(selectedShape.getColor());
			break;
		default:
		}
		GUIFunctions.refresh();
	}

	public void mousePressed(Point point) {
		this.downPoint = point;

		switch(selectedState){
		case NONE:
			// Do nothing
			break;
		case SELECT_SHAPE:
			if(selectedShape == null) return;
			if(HandleHitTester.isHittingLineHandles(point, selectedShape)){
				downPoint = HandleHitTester.getOppositeLineHandle(point, selectedShape);
				selectedHandle = true;
			} else if(HandleHitTester.isHittingTriangleHandles(point, selectedShape)){
				selectedTriangle = true;
				trianglePoints = HandleHitTester.getOppositeTriangleHandles(point, selectedShape);
			} else if(HandleHitTester.isHittingBoxHandles(point, selectedShape)){
				downPoint = HandleHitTester.getOppositeBoxHandle(point, selectedShape);
				selectedHandle = true;
			} else if(HandleHitTester.isHittingRotationHandle(point, selectedShape)){
				selectedRotation = true;
			} else if(selectedShape == ShapeHitTester.findSelectedShape(point)){
				selectedDragging = true;
				draggingOffset = new Point(
						point.x - selectedShape.getCenterPoint().x,
						point.y - selectedShape.getCenterPoint().y);
				if(selectedShape.getType() == ShapeType.LINE)
					draggingOffset = new Point(
							point.x - ((Line)selectedShape).getP1().x,
							point.y - ((Line)selectedShape).getP1().y
							);
			}
			GUIFunctions.refresh();
			break;
		default:
			// Store downPoint and add a new shape
			ShapeUpdater.addShape(selectedState, downPoint, selectedColor);
			GUIFunctions.refresh();
		}
	}

	public void mouseDragged(Point point) {

		switch(selectedState){
		case NONE:
			// Do nothing
			break;
		case SELECT_SHAPE:
			if(selectedShape == null) return;
			if(selectedHandle){
				ShapeUpdater.updateShape(selectedShape, downPoint, point);
			} else if(selectedRotation){
				selectedShape.setRotation(Utility.calcRotationAngle(selectedShape, point));
			} else if(selectedTriangle){
				trianglePoints.add(point);
				ShapeUpdater.updateTriangle(selectedShape, trianglePoints);
				trianglePoints.remove(point);
			} else if(selectedDragging){
				ShapeUpdater.translateShape(selectedShape, point, draggingOffset);
			}
			break;
		default:
			// Update drawing shape
			ShapeUpdater.updateLastShape(downPoint, point);
		}
		GUIFunctions.refresh();
	}

	public void mouseReleased(Point point) {
		downPoint = null;
		draggingOffset = null;
		selectedHandle = false;
		selectedRotation = false;
		selectedDragging = false;
		selectedTriangle = false;
		GUIFunctions.refresh();
	}
	
	@Override
	public String toString() {
		return "Controller [selectedState=" + selectedState
				+ ", selectedHandle=" + selectedHandle + ", selectedShape="
				+ selectedShape + ", downPoint=" + downPoint + "]";
	}
}