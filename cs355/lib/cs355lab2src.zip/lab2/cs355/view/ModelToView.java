package cs355.view;

import java.awt.Point;

import cs355.model.Line;
import cs355.model.Triangle;

public class ModelToView {

	public ModelToView() {	}

	public static Point getPoint1(Line l) {
		return l.getP1();
	}
	
	public static Point getPoint2(Line l) {
		return l.getP2();
	}

	public static int[] getTriangleXs(Triangle t) {
		int[] xPoints = new int[3];
		xPoints[0] = t.getP1().x;
		xPoints[1] = t.getP2().x;
		xPoints[2] = t.getP3().x;
		return xPoints;
	}
	
	public static int[] getTriangleYs(Triangle t) {
		int[] yPoints = new int[3];
		yPoints[0] = t.getP1().y;
		yPoints[1] = t.getP2().y;
		yPoints[2] = t.getP3().y;
		return yPoints;
	}
}
