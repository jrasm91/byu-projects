package cs355.model;

public enum ShapeType {
	
	Line, Rectangle, Square, Ellipse, Circle, Triangle, None;

}
