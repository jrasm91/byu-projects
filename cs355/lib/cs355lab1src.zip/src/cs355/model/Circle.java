package cs355.model;

import java.awt.Color;
import java.awt.Point;

public class Circle extends Shape {

	private Point centerPoint;
	private int radius;
	
	public Circle(Point centerPoint, int radius, Color color) {
		this.centerPoint = centerPoint;
		this.radius = radius;
		this.color = color;
		this.type = ShapeType.Circle;
	}
	
	public Point getCenterPoint(){
		return centerPoint;
	}
	
	public int getRadius(){
		return radius;
	}
	
	public void setCenterPoint(Point point){
		this.centerPoint = point;
	}
	
	public void setRadius(int radius){
		this.radius = radius;
	}
}
