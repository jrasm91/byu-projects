package cs355.model;

import java.awt.Color;
import java.awt.Point;

public class Rectangle extends Shape {
	
	private Point topLeftPoint;
	private int height, width;
	
	public Rectangle(Point topLeftPoint, int height, int width, Color color){
		this.topLeftPoint = topLeftPoint;
		this.height = height;
		this.width = width;
		this.color = color;		
		this.type = ShapeType.Rectangle;
	}
	
	public Point getTopLeftPoint(){
		return topLeftPoint;
	}
	
	public int getHeight(){
		return height;
	}
	
	public int getWidth(){
		return width;
	}

	public void setTopLeftPoint(Point point) {
		this.topLeftPoint = point;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void setWidth(int width) {
		this.width = width;
	}
}
