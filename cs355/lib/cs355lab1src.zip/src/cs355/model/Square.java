package cs355.model;

import java.awt.Color;
import java.awt.Point;

public class Square extends Shape {
	
	private Point topLeftPoint;
	private int length;
	
	public Square(Point topLeftPoint, int length, Color color){
		this.topLeftPoint = topLeftPoint;
		this.length = length;
		this.color = color;	
		this.type = ShapeType.Square;
	}
	
	public Point getTopLeftPoint(){
		return topLeftPoint;
	}
	
	public int getLength(){
		return length;
	}

	public void setTopLeftPoint(Point topLeftPoint) {
		this.topLeftPoint = topLeftPoint;
	}

	public void setLength(int length) {
		this.length = length;
	}
}