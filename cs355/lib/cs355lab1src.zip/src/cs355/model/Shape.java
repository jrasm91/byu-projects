package cs355.model;

import java.awt.Color;

public abstract class Shape {

	protected Color color;
	protected ShapeType type;
	
	public Color getColor(){
		return color;
	}
	
	public ShapeType getType(){
		return type;
	}

}
