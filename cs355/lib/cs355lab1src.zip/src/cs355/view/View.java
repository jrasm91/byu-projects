package cs355.view;

import java.awt.Graphics2D;

import cs355.gui.ViewRefresher;
import cs355.model.Circle;
import cs355.model.Ellipse;
import cs355.model.Line;
import cs355.model.Model;
import cs355.model.Rectangle;
import cs355.model.Shape;
import cs355.model.Square;
import cs355.model.Triangle;

public class View implements ViewRefresher{

	private static View singleton = new View();

	private View(){

	}

	public static View singleton(){
		return singleton;
	}

	@Override
	public void refreshView(Graphics2D g2d) {
		drawShapes(g2d);
	}

	private void drawShapes(Graphics2D g){
		for(Shape s: Model.singleton().getShapes()){
			switch(s.getType()){
			case Line: 		drawLine(g, (Line)s); 				break;
			case Rectangle: drawRectangle(g, (Rectangle)s);		break;
			case Square:	drawSquare(g, (Square)s);			break;
			case Ellipse:	drawEllipse(g, (Ellipse)s);			break;
			case Circle:	drawCircle(g, (Circle)s);			break;
			case Triangle: 	drawTriangle(g, (Triangle)s);		break;
			case None:				
				break;
			}
		}
	}

	private void drawLine(Graphics2D g, Line l){
		g.setColor(l.getColor());
		g.drawLine((int)l.getP1().getX(), 
				(int)l.getP1().getY(), 
				(int)l.getP2().getX(), 
				(int)l.getP2().getY());		
	}

	private void drawSquare(Graphics2D g, Square s){
		g.setColor(s.getColor());
		g.fillRect((int)s.getTopLeftPoint().getX(), 
				(int)s.getTopLeftPoint().getY(), 
				s.getLength(), 
				s.getLength());
	}

	private void drawRectangle(Graphics2D g, Rectangle r){
		g.setColor(r.getColor());
		g.fillRect((int)r.getTopLeftPoint().getX(), 
				(int)r.getTopLeftPoint().getY(), 
				r.getWidth(),
				r.getHeight());
	}

	private void drawCircle(Graphics2D g, Circle c){
		g.setColor(c.getColor());
		g.fillOval((int)c.getCenterPoint().x - c.getRadius(), 
				(int)c.getCenterPoint().y - c.getRadius(), 
				c.getRadius() * 2, 
				c.getRadius() * 2);
	}

	private void drawEllipse(Graphics2D g, Ellipse e){
		g.setColor(e.getColor());
		g.fillOval((int)e.getCenterPoint().getX() - e.getWidth(), 
				(int)e.getCenterPoint().getY() - e.getHeight(), 
				e.getWidth() * 2, 
				e.getHeight() * 2);
	}

	private void drawTriangle(Graphics2D g, Triangle t){
		g.setColor(t.getColor());
		int[] xPoints = {(int)t.getP1().getX(), 
				(int)t.getP2().getX(), 
				(int)t.getP3().getX()};
		int[] yPoints = {(int)t.getP1().getY(), 
				(int)t.getP2().getY(), 
				(int)t.getP3().getY()};
		int nPoints = 3;
		g.fillPolygon(xPoints, yPoints, nPoints);
	}
}
