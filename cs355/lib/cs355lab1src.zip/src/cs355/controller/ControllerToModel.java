package cs355.controller;

import java.awt.Color;
import java.awt.Point;

import cs355.model.Circle;
import cs355.model.Ellipse;
import cs355.model.Line;
import cs355.model.Model;
import cs355.model.Rectangle;
import cs355.model.Shape;
import cs355.model.ShapeType;
import cs355.model.Square;
import cs355.model.Triangle;

public class ControllerToModel {

	/**
	 * @param s The type of shape that is now being drawn
	 * @param p1 The first initial point (downClick)
	 * @param c The color of the shape
	 */
	public static void addShape(ShapeType s, Point p1, Color c){
		switch(s){
		case Circle: 	Model.singleton().addShape(new Circle(p1, 0, c));			break;
		case Ellipse:	Model.singleton().addShape(new Ellipse(p1, 0, 0, c));		break;
		case Line:		Model.singleton().addShape(new Line(p1, p1, c));			break;
		case Rectangle:	Model.singleton().addShape(new Rectangle(p1, 0, 0, c));		break;
		case Square:	Model.singleton().addShape(new Square(p1, 0, c));			break;
		case Triangle:
		case None:
			return;
		default:
			throw new IllegalArgumentException(s.toString());
		}
		System.out.println("Added: " + s);
	}

	/**
	 * Same as above but for a triangle (special case)
	 */
	public static void addShape(Point p1, Point p2, Point p3, Color c){
		Model.singleton().addShape(new Triangle(p1, p2, p3, c));
		System.out.println("Added: Triangle");
	}

	/**
	 * @param downPoint The first click of the mouse
	 * @param mousePoint The current location of the mouse
	 */
	public static void updateLastShape(Point downPoint, Point mousePoint) {
		Shape lastShape = Model.singleton().getLastShape();
		switch(lastShape.getType()){
		case Circle: 	updateCircle((Circle)lastShape, downPoint, mousePoint);			break;
		case Ellipse:	updateEllipse((Ellipse)lastShape, downPoint, mousePoint);		break;
		case Line:		updateLine((Line)lastShape, downPoint, mousePoint);				break;
		case Rectangle:	updateRectangle((Rectangle)lastShape, downPoint, mousePoint);	break;
		case Square: 	updateSquare((Square)lastShape, downPoint, mousePoint);			break;
		case Triangle:
			break;
		default:
			throw new IllegalArgumentException(lastShape.getType().toString());
		}
	}

	private static void updateRectangle(Rectangle r, Point downPoint, Point mousePoint){
		r.setTopLeftPoint(findTopLeft(downPoint, mousePoint));
		r.setHeight(findDy(downPoint, mousePoint));
		r.setWidth(findDx(downPoint, mousePoint));
	}

	private static void updateSquare(Square s, Point downPoint, Point mousePoint){
		updateLowPoint(downPoint, mousePoint);
		s.setTopLeftPoint(findTopLeft(downPoint, mousePoint));
		s.setLength(findLength(downPoint, mousePoint));
	}

	private static void updateCircle(Circle c, Point downPoint, Point mousePoint){
		updateLowPoint(downPoint, mousePoint);
		Point topLeft = findTopLeft(downPoint, mousePoint);
		int length = findLength(downPoint, mousePoint);
		c.setCenterPoint(new Point(topLeft.x + length/2 , topLeft.y + length/2));
		c.setRadius(length/2);
	}

	private static void updateEllipse(Ellipse e, Point downPoint, Point mousePoint){
		int dx = findDx(downPoint, mousePoint);
		int dy = findDy(downPoint, mousePoint);
		Point topLeft = findTopLeft(downPoint, mousePoint);
		e.setCenterPoint(new Point(topLeft.x + dx/2, topLeft.y + dy/2));
		e.setHeight(dy/2);
		e.setWidth(dx/2);
	}

	private static void updateLine(Line l, Point downPoint, Point mousePoint){
		l.setP1(downPoint);
		l.setP2(mousePoint);
	}

	public static void updateTriangle(Triangle t, Point p1, Point p2, Point p3){
		t.setP1(p1);
		t.setP2(p2);
		t.setP3(p3);
	}

	private static void updateLowPoint(Point downPoint, Point mousePoint){
		int length = findLength(downPoint, mousePoint);
		mousePoint.x = mousePoint.x < downPoint.x? downPoint.x - length : mousePoint.x;
		mousePoint.y = mousePoint.y < downPoint.y? downPoint.y - length : mousePoint.y;
	}

	private static Point findTopLeft(Point p1, Point p2) {
		int minX = (int) Math.min(p1.x, p2.x);
		int minY = (int) Math.min(p1.y, p2.y);
		return new Point(minX, minY);
	}

	private static int findDx(Point p1, Point p2){
		return (int) Math.abs(p1.x - p2.x);
	}

	private static int findDy(Point p1, Point p2){
		return (int) Math.abs(p1.y - p2.y);
	}

	private static int findLength(Point p1, Point p2){
		int dx = findDx(p1, p2);
		int dy = findDy(p1, p2);
		return (int)Math.min(dx, dy);
	}
}
