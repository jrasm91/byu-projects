package cs355.controller;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import cs355.gui.GUIFunctions;
import cs355.model.ShapeType;

public class Controller implements cs355.gui.CS355Controller {

	private static Controller singleton = new Controller();

	private Color selectedColor;
	private ShapeType selectedShape;

	private List<Point> trianglePoints;
	private Point downPoint;

	private Controller(){

		selectedColor = Color.WHITE;
		selectedShape = ShapeType.None;
		trianglePoints = new ArrayList<Point>();
		downPoint = null;
	}

	public static Controller singleton(){
		return singleton;
	}
	
	/**
	 * Clears the list of points for the triangle (all it does so far) 
	 */
	private void reset(){
		trianglePoints.clear();
	}

	@Override
	public void colorButtonHit(Color c) {
		if(c == null) return;
		selectedColor = c;	
		GUIFunctions.changeSelectedColor(c);
	}

	@Override
	public void triangleButtonHit() {
		selectedShape = ShapeType.Triangle;
		reset();
	}

	@Override
	public void squareButtonHit() {
		selectedShape = ShapeType.Square;
		reset();
	}

	@Override
	public void rectangleButtonHit() {
		selectedShape = ShapeType.Rectangle;
		reset();
	}

	@Override
	public void circleButtonHit() {
		selectedShape = ShapeType.Circle;		
		reset();
	}

	@Override
	public void ellipseButtonHit() {
		selectedShape = ShapeType.Ellipse;	
		reset();	
	}

	@Override
	public void lineButtonHit() {
		selectedShape = ShapeType.Line;		
		reset();
	}

	@Override
	public void selectButtonHit() {
		selectedShape = ShapeType.None;
		reset();
	}

	@Override
	public void zoomInButtonHit() {
		// TODO Auto-generated method stub
	}

	@Override
	public void zoomOutButtonHit() {
		// TODO Auto-generated method stub
	}

	@Override
	public void hScrollbarChanged(int value) {
		// TODO Auto-generated method stub
	}

	@Override
	public void vScrollbarChanged(int value) {
		// TODO Auto-generated method stub
	}

	public void mouseDragged(Point point) {
		if(selectedShape == ShapeType.None)
			return;
		ControllerToModel.updateLastShape(downPoint, point);
		GUIFunctions.refresh();
	}

	public void mousePressed(Point point) {
		System.out.println("Mouse Pressed");
		downPoint = point;
		ControllerToModel.addShape(selectedShape, point, selectedColor);
		GUIFunctions.refresh();
	}

	public void mouseReleased(Point point) {
		System.out.println("Mouse Released");
		downPoint = null;
		GUIFunctions.refresh();
	}

	public void mouseMoved(Point point) {
		//TODO
		//		System.out.println("Mouse Moved");
	}

	public void mouseClicked(Point point) {
		System.out.println("Mouse Clicked");
		if(selectedShape != ShapeType.Triangle)
			return;
		trianglePoints.add(point);
		if(trianglePoints.size() == 3){
			ControllerToModel.addShape(
					trianglePoints.get(0), 
					trianglePoints.get(1), 
					trianglePoints.get(2),
					selectedColor);
			trianglePoints.clear();
		}
		GUIFunctions.refresh();
	}
}
