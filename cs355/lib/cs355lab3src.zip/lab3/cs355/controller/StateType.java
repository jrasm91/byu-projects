package cs355.controller;

public enum StateType {
	DRAW_LINE, 
	DRAW_RECTANGLE, 
	DRAW_SQUARE, 
	DRAW_ELLIPSE, 
	DRAW_CIRCLE, 
	DRAW_TRIANGLE, 
	SELECT_SHAPE, 
	NONE;
}
