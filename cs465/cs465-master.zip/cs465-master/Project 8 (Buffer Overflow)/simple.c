#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int freshman(int a, int b, int c) {

  char housing[30] = "Helaman Halls";
  return 1;
}



int main()
{

  int year = 61166;
  int month = 254;
  int day = 253;

  int result = freshman (month, day, year);

  exit(0);
}
